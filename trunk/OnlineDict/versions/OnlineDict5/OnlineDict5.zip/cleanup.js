﻿var body = document.getElementsByTagName("body")[0];
var x_offset = 10;
var y_offset = 170;

alert("clean up!");
